I made it so that if any firespitter part (including my parts) need extra skins, it is required to use a patch. This is for easy uninstallation.

If you would like to remove these extra skins, you may delete the 'skins' folder which is located in the path FirespitterExtended/Assets/skins.
For the removal of extra pilots, remove the 'pilots' folder located in FirespitterExtended/Assets/pilots.
Make sure to delete the cfg file that matches with what you deleted.

You don't need one or the other! If you just wanted extra skins, you could delete the pilots folder and cfg, or vice versa.